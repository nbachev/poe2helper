"""Проверка, что окна собираются и не падают.

Запускается там, где установлен PySide6 (в CI — на windows-latest
с ``QT_QPA_PLATFORM=offscreen``). Локально без Qt тест пропускается.
"""

import os
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

try:
    from PySide6.QtWidgets import QApplication

    HAS_QT = True
except ImportError:  # pragma: no cover
    HAS_QT = False

from fixtures import RARE_GLOVES, STATS_PAYLOAD, UNIQUE_AMULET  # noqa: E402
from poe2helper.config import Config  # noqa: E402
from poe2helper.parser.item import parse_item  # noqa: E402
from poe2helper.parser.stats_db import StatsDB  # noqa: E402


class FakeCtx:
    """Минимальная замена AppController для тестов виджетов."""

    def __init__(self):
        self.cfg = Config()
        self.cfg.set("search.auto_search_on_open", False)
        self.cfg.set("league", "Test League")
        self.stats_db = StatsDB.from_api_payload(STATS_PAYLOAD)
        self.league = "Test League"
        self.trade = None
        self.ninja = None
        self.warnings: list[str] = []
        self.notifications: list[tuple[str, str]] = []

    def notify(self, title, message):
        self.notifications.append((title, message))

    def apply_settings(self):
        pass

    def reload_stats(self, silent=True):
        pass

    def refresh_league(self):
        pass


@unittest.skipUnless(HAS_QT, "PySide6 не установлен")
class TestUiSmoke(unittest.TestCase):
    app = None

    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_overlay_builds_and_shows_item(self):
        from poe2helper.ui.overlay import PriceCheckOverlay

        ctx = FakeCtx()
        overlay = PriceCheckOverlay(ctx)
        item = parse_item(RARE_GLOVES)
        overlay.show_item(item)

        self.assertEqual(len(overlay.rows), len(item.mods))
        self.assertIn("Havoc Grasp", overlay.lbl_title.text())
        enabled = [m for m in overlay.mod_filters if m.enabled]
        self.assertTrue(enabled, "хотя бы один мод должен быть включён по умолчанию")

        # переключение галочек и границ не должно падать
        overlay._set_all(False)
        self.assertFalse([m for m in overlay.mod_filters if m.enabled])
        overlay._set_all(True)
        overlay._sync_options()
        overlay.rows[0].min_spin.set_bound(10)
        overlay.rows[0].min_spin.valueChanged.emit(10)
        self.assertEqual(overlay.mod_filters[0].min_value, 10)

        # удаление строки
        before = len(overlay.rows)
        overlay._remove_row(overlay.rows[0])
        self.assertEqual(len(overlay.rows), before - 1)

        overlay.hide()
        overlay.deleteLater()

    def test_overlay_handles_unique(self):
        from poe2helper.ui.overlay import PriceCheckOverlay

        ctx = FakeCtx()
        overlay = PriceCheckOverlay(ctx)
        overlay.show_item(parse_item(UNIQUE_AMULET))
        self.assertTrue(overlay.chk_rarity.isChecked())
        self.assertEqual(overlay.cmb_rarity.currentData(), "unique")
        overlay.hide()
        overlay.deleteLater()

    def test_add_mod_dialog_search(self):
        from poe2helper.ui.addmod import AddModDialog

        ctx = FakeCtx()
        dialog = AddModDialog(ctx.stats_db)
        self.assertGreater(dialog.list.count(), 0)
        dialog.search.setText("attack speed")
        dialog._refresh()
        self.assertGreater(dialog.list.count(), 0)
        dialog._accept()
        self.assertIsNotNone(dialog.selected_entry)
        dialog.deleteLater()

    def test_add_mod_dialog_options(self):
        from poe2helper.ui.addmod import AddModDialog

        ctx = FakeCtx()
        dialog = AddModDialog(ctx.stats_db)
        dialog.search.setText("allocates")
        dialog._refresh()
        self.assertTrue(dialog.option_box.isVisible() or dialog.option_box.count() > 0)
        dialog.deleteLater()

    def test_main_window_builds(self):
        from poe2helper.ui.main_window import MainWindow

        ctx = FakeCtx()
        window = MainWindow(ctx)
        self.assertEqual(window.tabs.count(), 3)
        self.assertIn("Test League", window.lbl_league.text())

        thresholds, groups = window._collect_thresholds()
        self.assertIn("currency", thresholds)
        self.assertTrue(all(isinstance(v, float) for v in thresholds["currency"]))
        self.assertIn("currency", groups)

        window.edit_filter_path.setText("C:/tmp/my.filter")
        window.save_settings(silent=True)
        self.assertEqual(ctx.cfg.get("filter.path"), "C:/tmp/my.filter")
        window.deleteLater()

    def test_main_window_scan_groups(self):
        import tempfile

        from fixtures import FILTER_SAMPLE
        from poe2helper.ui.main_window import MainWindow

        ctx = FakeCtx()
        window = MainWindow(ctx)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "sample.filter"
            path.write_text(FILTER_SAMPLE, encoding="utf-8")
            window.edit_filter_path.setText(str(path))
            window._scan_groups()

        _, groups = window._collect_thresholds()
        self.assertEqual(groups, ["currency"])
        self.assertIn("currency", window.filter_output.toPlainText())
        window.deleteLater()

    def test_icon_renders(self):
        from poe2helper.app import make_icon

        icon = make_icon()
        self.assertFalse(icon.isNull())


if __name__ == "__main__":
    unittest.main()
